import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-audio-capture',
  templateUrl: './audio-capture.component.html',
  styleUrls: ['./audio-capture.component.scss']
})
export class AudioCaptureComponent implements OnInit {

  private audioChunks: Blob[] = [];
  private stream!: MediaStream;
  isRecording: boolean = false;
  audioUrl:string = "";
  selectedFile!:File;

  socket: WebSocket;
  public transcribedText = '';
  private mediaRecorder!: MediaRecorder;

  constructor() {
    this.socket = new WebSocket('ws://localhost:8765');
  }


  ngOnInit(): void {
    this.socket.onopen = () => {
      console.log('WebSocket connection opened');
    };
    this.socket.onmessage = (event) => {
      console.log('Message from server: ', event.data);
    };
    this.socket.onclose = () => {
      console.log('WebSocket connection closed');
    };
  }

  ngOnDestroy(): void {
    if (this.mediaRecorder && this.mediaRecorder.state !== 'inactive') {
      this.mediaRecorder.stop();
    }
    if (this.socket && this.socket.readyState === WebSocket.OPEN) {
      this.socket.close();
    }
  }

  startRecording() {
    navigator.mediaDevices.getUserMedia({
      audio: {
        sampleRate: 44100, // Specify the desired sample rate
        channelCount: 1, // Specify the desired number of channels (1 for mono, 2 for stereo)
        width: 2
      }
    }).then(stream => {
        this.mediaRecorder = new MediaRecorder(stream);
        this.mediaRecorder.ondataavailable = event => {
          this.audioChunks.push(event.data);
        };
        this.mediaRecorder.onstop = () => {
          const audioBlob = new Blob(this.audioChunks, { type: 'audio/wav' });
          this.sendAudioData(audioBlob);
          this.audioChunks = [];
        };
        if(this.mediaRecorder.state=="inactive"){
          this.stopRecording()
        }
        this.mediaRecorder.start();
      this.isRecording=true;
      })
      .catch(error => console.error('Error accessing audio devices:', error));
  }



  onFileSelected(event: any) {
    let waveFile = event.target.files[0];
    this,this.selectedFile = waveFile;
    this.startRecording1();
    // Call stopRecording after a short delay
    setTimeout(() => {
      this.stopRecording();
    }, 1000); // Adjust the delay as needed
  }

  startRecording1() {
    if (this.selectedFile) {
      const fileReader = new FileReader();
      fileReader.onload = () => {
        const fileContent = fileReader.result as ArrayBuffer;
        if (!this.socket || this.socket.readyState === WebSocket.CLOSED) {
          this.socket = new WebSocket('ws://localhost:8765');
        }
        if (this.socket.readyState === WebSocket.OPEN) {
          this.socket.send(fileContent);
          console.log('File content sent over WebSocket');
        } else {
          console.error('WebSocket connection is not open');
        }
      };
      fileReader.readAsArrayBuffer(this.selectedFile);
    } else {
      console.error('No file selected');
    }
  }


  stopRecording() {

    if (this.mediaRecorder) {

      this.mediaRecorder.onstop = () => {
        const audioBlob = new Blob(this.audioChunks, { type: 'audio/wav' });
        this.sendAudioData(audioBlob);
        this.audioChunks = [];
        this.mediaRecorder.stop();
        this.isRecording = false;
        return audioBlob;
      };
      this.mediaRecorder.stop();
    } else {
      console.error('No recording in progress');
    }
  }

  sendAudioData(audioBlob: Blob) {
    this.socket.send(audioBlob);
    // const reader = new FileReader();
    // reader.onloadend = () => {
    //   if (this.socket.readyState === WebSocket.OPEN) {
    //     console.log(reader.result)
    //     this.socket.send(reader.result);
    //   } else {
    //     console.error('WebSocket connection is not open');
    //   }
    // };
    console.log(audioBlob);
    // reader.readAsArrayBuffer(audioBlob);
  }



  // onFileSelected(event: Event): void {
  //   const input = event.target as HTMLInputElement;
  //   if (input.files && input.files.length > 0) {
  //     this.selectedFile = input.files[0];
  //     console.log('File selected:', this.selectedFile);
  //   }
  // }
  //
  // uploadFile(): void {
  //   if (this.selectedFile) {
  //     const formData = new FormData();
  //     formData.append('file', this.selectedFile, this.selectedFile.name);
  //
  //     this.fileUploadService.upload(formData).subscribe(response => {
  //         console.log('Upload successful', response);
  //       },
  //       error => {
  //         console.error('Upload error', error);
  //       }
  //     );
  //   } else {
  //     console.log('No file selected');
  //   }

}
