import { Injectable } from '@angular/core';
import { Observable, Subject } from 'rxjs';

@Injectable({
  providedIn: 'root'
})
export class WebSocketService {
  private socket: WebSocket;
  private textReceived = new Subject<string>();

  public onTextReceived: Observable<string> = this.textReceived.asObservable();

  constructor() {
    this.socket = new WebSocket('ws://localhost:8765');
    this.socket.onmessage = (event) => this.handleMessage(event);
  }

  public sendAudioData(data: Blob): void {
    console.log("sending"+data)
    this.socket.send(data);
  }

  private handleMessage(event: MessageEvent): void {
    const text = event.data;
    this.textReceived.next(text);
  }
}
